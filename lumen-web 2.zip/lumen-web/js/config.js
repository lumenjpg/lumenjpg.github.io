// ============================================================
//  PENGATURAN LUMEN  -  CUKUP EDIT FILE INI UNTUK UPDATE WEB
//  Simpan, lalu upload ulang. Jangan hapus tanda kutip " " atau koma ,
// ============================================================
var LUMEN_CONFIG = {
  nama: "Lumen",

  // Nomor WhatsApp: pakai 62, tanpa 0 di depan, tanpa spasi atau tanda +
  // Contoh: 0812-3456-7890 ditulis "6281234567890"
  nomorWA: "62XXXXXXXXXX",

  // Harga per bulan, ANGKA SAJA tanpa titik. 125000 tampil jadi Rp125.000
  harga: 125000,

  // Kecepatan dalam Mbps
  speedMin: 5,    // yang dijamin
  speedMax: 10,   // bonus, tidak dijamin

  // Pesan otomatis yang muncul di WhatsApp calon pelanggan.
  // {harga} akan diganti otomatis dengan harga di atas.
  pesanWA: "Halo Lumen, saya mau daftar internet {harga}/bulan."
};
