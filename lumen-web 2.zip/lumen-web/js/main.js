// Mengisi halaman dari config.js. Biasanya tidak perlu diubah.
(function () {
  var C = window.LUMEN_CONFIG;
  var harga = "Rp" + C.harga.toLocaleString("id-ID");
  var isi = { nama: C.nama, harga: harga, speedMin: C.speedMin, speedMax: C.speedMax };

  document.querySelectorAll("[data-fill]").forEach(function (el) {
    var k = el.getAttribute("data-fill");
    if (k in isi) el.textContent = isi[k];
  });

  document.title = C.nama + " - Internet Rumahan " + harga + "/bulan";

  var pesan = encodeURIComponent(C.pesanWA.replace("{harga}", harga));
  document.querySelectorAll("[data-wa]").forEach(function (a) {
    a.href = "https://wa.me/" + C.nomorWA + "?text=" + pesan;
  });
})();
